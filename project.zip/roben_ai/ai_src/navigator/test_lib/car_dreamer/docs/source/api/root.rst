:py:mod:`car_dreamer`
================================

.. py:module:: car_dreamer

If you want to directly use our tasks without creating customized environments, the following functions are just enough for you. See :doc:`../tasks` for possible tasks and configurations.

.. autofunction:: create_task

.. autofunction:: load_task_configs
